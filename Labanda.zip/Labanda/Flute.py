from Instrument import Instrument


class Flute(Instrument):
    def __init__(self, sound):
        self.__init__(sound) 
