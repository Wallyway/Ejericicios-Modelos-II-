from Instrument import Instrument


class Accordion(Instrument):
<<<<<<< HEAD
    def __init__(self, sound) -> None:
        super().__init__(sound)
=======
    def __init__(self):
        self.instrument_type = 'Acordion'

    def play(self):
        print(f'{self.instrument_type}')
        
    def tune(self):
        print(f'{self.instrument_type}')    
	
>>>>>>> f5dde7068ba200adaa2ca81bf788ff5983bf9d1c
