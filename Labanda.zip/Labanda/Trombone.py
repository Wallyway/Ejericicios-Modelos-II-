from Instrument import Instrument


class Trombone(Instrument):
    def __init__(self, sound):
        super().__init__(sound)
