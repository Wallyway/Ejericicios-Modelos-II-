class Instrument:
<<<<<<< HEAD

    def __init__(self, sound):
        self.sound = sound

    def play(self):
        print(self.sound)
=======
    def play(self):
        pass
>>>>>>> f5dde7068ba200adaa2ca81bf788ff5983bf9d1c
