from Instrument import Instrument


class Vihuela(Instrument):
         
    def __init__(self, sound):
        super().__init__(sound)	
