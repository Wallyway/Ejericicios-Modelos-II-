from Instrument import Instrument


class Guitarron(Instrument):

    def __init__(self, sound):
        super().__init__(sound)
